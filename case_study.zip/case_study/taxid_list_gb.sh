#!/bin/sh
if ! grep 'taxon:' *.gb > outfile; then
    rm -f outfile
    exit
else
sed 's/.*taxon//g' outfile > outfile1
sed 's/.//;s/.$//' outfile1 > taxid_list_gb.tsv
fi
rm outfil*
