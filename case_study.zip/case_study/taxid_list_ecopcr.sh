#!/bin/sh
awk '{print $5}' *.ecopcr > output
grep '^[0-9]' output > taxid_list_ecopcr.tsv
rm output
